import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class HelloWorld {
	public HelloWorld() {}
	
  public static void main(String[] args) {
    StdOut.println("Hello, World");
  }
}